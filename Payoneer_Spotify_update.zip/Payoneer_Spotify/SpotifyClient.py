import spotipy
from spotipy import SpotifyOAuth
from Payoneer_Spotify.MusicClient import MusicClient
import pandas as pd

"""
This SpotifyClient class is a child (derived) class of MusicClient - and therefore complies
(and also implements) the 3 abstract methods of the parent MusicClient. User needs to input 
their Spotify 'Client ID' and 'Client Secret' below (in 'cid' and 'secret' respectively). These can be
found in the 'Spotify for Developers' dashboard after creating a new app (in the main page of the newly 
created app). 
"""

cid = 'e22d6879464e48118294fe0c615ef873'  # user input here
secret = '2666f04e039843068cbaf2b457b40d9a'  # user input here
SCOPE = 'user-top-read'
SPOTIPY_REDIRECT_URI = 'http://localhost:8888/callback/'
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(client_id=cid, client_secret=secret,
                                               redirect_uri=SPOTIPY_REDIRECT_URI, scope=SCOPE))


class SpotifyClient(MusicClient):

    def get_current_user_top_tracks(self, N, time_range):
        top_tracks = sp.current_user_top_tracks(limit=N, time_range=time_range)
        df = pd.DataFrame.from_dict(top_tracks)
        df_new = pd.DataFrame(
            columns=['track_name', 'track_id', 'track_popularity', 'track_duration_ms', 'album_id', 'album_name',
                     'album_release_date', 'album_image_url', 'artist_id', 'artist_name'])

        for i in range(N):
            df_new.loc[df_new.shape[0]] = [df.loc[i, 'items']['name'],
                                           df.loc[i, 'items']['id'],
                                           df.loc[i, 'items']['popularity'],
                                           df.loc[i, 'items']['duration_ms'],
                                           df.loc[i, 'items']['album']['id'],
                                           df.loc[i, 'items']['album']['name'],
                                           df.loc[i, 'items']['album']['release_date'],
                                           df.loc[i, 'items']['album']['images'][0]['url'],
                                           df.loc[i, 'items']['album']['artists'][0]['id'],
                                           df.loc[i, 'items']['album']['artists'][0]['name']]

        return df_new

    def question_one(self, N, time_range):
        df_solution = self.get_current_user_top_tracks(N, time_range)
        return df_solution.groupby('artist_name')['track_name'].nunique().sort_values(ascending=False)

    def question_two(self, N, time_range):
        df_solution = self.get_current_user_top_tracks(N, time_range)
        return df_solution.groupby('artist_name')['album_name'].nunique().sort_values(ascending=False)
