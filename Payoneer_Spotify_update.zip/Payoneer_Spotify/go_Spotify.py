from Payoneer_Spotify.SpotifyClient import SpotifyClient

if __name__ == "__main__":
    """
    This is the main program for running and displaying the solutions to the Payoneer home task.
    Each of the 3 'print' commands below answers the 3 questions (testing with Unittest is in another file).
    In the below two lines user needs to input a value for N - number of tracks to return (N <= 50)
    and input time_range - should be one of these: ['short_term', 'medium_term', 'long_term']:
    """

N = 6  # user input here
time_range = 'long_term'  # user input here
spotify_client = SpotifyClient()
df_solution = spotify_client.get_current_user_top_tracks(N, time_range)
print(df_solution)
answer_one = spotify_client.question_one(N, time_range)
print(answer_one)
answer_two = spotify_client.question_two(N, time_range)
print(answer_two)
