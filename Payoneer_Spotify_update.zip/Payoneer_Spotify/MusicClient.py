from abc import ABC, abstractmethod

"""
The MusicClient class is an abstract class that defines the 'contract' which must be implemented by
any child (derived) class who wants to comply by the rules and definitions of being also a MusicClient.
Currently it defines 3 abstract methods which all child classes must fulfill. 
"""


class MusicClient(ABC):
    @abstractmethod
    def get_current_user_top_tracks(self, N, time_range):
        """
        return a df with current user top N tracks played by time range
        :param N: number of tracks to return (<= 50)
        :param time_range: should be one of these:
            ['short_term', 'medium_term', 'long_term']:
        return: pandas DataFrame with columns:
            ['track_name', 'track_id', 'track_popularity', 'track_duration_ms', 'album_id', 'album_name',
            'album_release date', 'album_image_url', 'artist_id', 'artist_name']
        """
        pass
        raise Exception

    @abstractmethod
    def question_one(self, N, time_range):
        """
        function that returns the current user top N artists with number of different tracks played recently
        """
        pass
        raise Exception

    @abstractmethod
    def question_two(self, N, time_range):
        """
        function that returns the current user top N artists with number of different albums played recently
        """
        pass
        raise Exception
