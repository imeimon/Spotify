import unittest
from Payoneer_Spotify.SpotifyClient import SpotifyClient

"""
This file is a unittest file running on the 'Python tests' configuration template of the PyCharm IDE.
All methods beginning with 'test_' are automatically detected and could be validated and run 
when choosing this configuration.
As with the go_Spotify.py file, the user needs to input a value for N - number of tracks to return (N <= 50)
and input time_range - should be one of these: ['short_term', 'medium_term', 'long_term']:
"""

spotify_client = SpotifyClient()
N = 6  # user input here
time_range = 'long_term'  # user input here
df = SpotifyClient.get_current_user_top_tracks(spotify_client, N, time_range)


class TestSpotifyClient(unittest.TestCase):

    def test_column_names(self):
        """This test validates that the column names of the returned dataframe match those required
        in the Payoneer assignment (the get_current_user_top_tracks method)"""

        column_names_list = ['track_name', 'track_id', 'track_popularity', 'track_duration_ms', 'album_id',
                             'album_name', 'album_release_date', 'album_image_url', 'artist_id', 'artist_name']
        list_to_test = df.columns.tolist()
        self.assertListEqual(list_to_test, column_names_list)

    def test_track_count(self):
        """This test validates that the number of rows in the returned dataframe matches N
        (the number of tracks to return which was input by the user above)"""

        self.assertTrue(len(df) == N)

    def test_unique_tracks_albums(self):
        """This test compares the output of questions 1 & 2 and validates that the number of unique tracks
         per artist is always equal to or greater than the number of unique albums per artist. Regardless
         of individual top tracks played, this must always be true."""

        df_tracks = spotify_client.question_one(N, time_range)
        df_albums = spotify_client.question_two(N, time_range)
        unique_tracks_count = df_tracks.to_list()
        unique_albums_count = df_albums.to_list()
        self.assertTrue(all([a >= b for a, b in zip(unique_tracks_count, unique_albums_count)]))
